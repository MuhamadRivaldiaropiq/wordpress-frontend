import{G as t}from"./index-65396532.js";const e=t.create({withCredentials:!0});export{e as a};
